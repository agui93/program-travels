---
name: Feature request
about: Suggest an idea for this project
labels: enhancement

---

<!--
Please fill in as much of the template below as you're able.
-->

### Is your feature request related to a problem? Please describe.
<!--
Place description here
-->

### Describe the solution you'd like
<!--
Place description here
-->

### Describe alternative solutions or features you've considered
<!--
Place description here
-->
