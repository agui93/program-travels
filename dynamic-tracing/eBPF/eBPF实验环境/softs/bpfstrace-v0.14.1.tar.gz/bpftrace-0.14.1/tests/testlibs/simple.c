__attribute__((__visibility__("default"))) void fun()
{
}
