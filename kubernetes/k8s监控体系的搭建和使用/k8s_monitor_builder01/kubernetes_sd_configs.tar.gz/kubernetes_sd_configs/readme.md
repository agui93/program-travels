
https://github.com/kubernetes/kube-state-metrics/tree/main/examples/standard

https://www.cuiliangblog.cn/detail/article/31

ChatGPT


https://www.fdevops.com/2022/02/14/prometheus-kube-state-metrics
https://www.cnblogs.com/qianyuliang/p/10542886.html


